<div class="foot1">
<div class="policies">
  <i class="material-icons">&#xE558;</i>&nbsp;2-3 Days Delivery&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <i class="material-icons">&#xE8DC;</i>&nbsp;Customer Satisfaction&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <i class="material-icons">&#xE532;</i>&nbsp;Free Shipping
 </div>
<div class="follow">
follow us on:<br>
<img src="img/insta1.png" height="36px" width="36px">
<img src="img/fb.png" height="40px" width="40px">
<img src="img/twitter.png" height="40px" width="40px">
</div>
<div class=last>
<div class="contact">
Contact-us:88888-99999
E-mail:wtlminiproject84@gmail.com
</div>
<div class="rights">
&copy;SPORTHOLICS. ALL RIGHTS RESERVED.
</div>
<div class="policy">
Privacy Policy|Terms and Conditions|About Us
</div>
</div>
</div>
