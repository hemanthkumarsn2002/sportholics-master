<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "sportholics";
$dbport = 3306;

$conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname, $dbport);
